# dosdatetime.py Version 1.0.0
# Copyright (c) 2023 <tnzw@github.triton.ovh>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

def dosdatetime(year, month, day, hour=0, minute=0, second=0):
  # https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-dosdatetimetofiletime
  # 0 <= second < 32 * 2, 0 <= minutes < 64, 0 <= hour < 32, 0 <= day < 32, 0 <= month < 16, 1980 <= year < 2108
  #if not (1980 <= year < 2108): raise NotImplementedError(f'dosdatetime() unhandled year {year}')
  if year < 1980: raise NotImplementedError(f'dosdatetime() unhandled year {year}')
  # bits YYYYYYMMMMMDDDDDhhhhhmmmmmmsssss
  return ((year - 1980) << 25) | (month << 21) | (day << 16) | (hour << 11) | (minute << 5) | int(second / 2)  # is uint32 or larger
