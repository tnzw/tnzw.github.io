# os_path_splitall.py Version 1.1.1
# Copyright (c) 2020, 2023 <tnzw@github.triton.ovh>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

def os_path_splitall(path, *, os_module=None):
  """\
os_path_splitall(path) -> list that can be restored as valid path by doing os.path.join.

    os_path_splitall('a/b/c') -> ['a', 'b', 'c']
    os_path_splitall('/a/b/c') -> ['/a', 'b', 'c']
"""
  if os_module is None: os_module = os
  split = os_module.path.split
  ph, t = split(path)
  r = [t]
  while 1:
    h, t = split(ph)
    if ph == h:
      r[0] = h + r[0]
      return r
    r.insert(0, t)
    ph = h
os_path_splitall._required_globals = ['os']
