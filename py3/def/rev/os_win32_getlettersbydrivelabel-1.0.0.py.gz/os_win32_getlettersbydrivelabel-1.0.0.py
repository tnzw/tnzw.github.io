# os_win32_getlettersbydrivelabel.py Version 1.0.0
# Copyright (c) 2020 Tristan Cavelier <t.cavelier@free.fr>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

# Requires: re subprocess
def os_win32_getlettersbydrivelabel():
  # try with https://stackoverflow.com/questions/8319264/how-can-i-get-the-name-of-a-drive-in-python
  cp = subprocess.run(["wmic", "volume", "get", "DriveLetter,Label"], input=b"", capture_output=True, check=True)
#  cp.stdout = """DriveLetter  Label
#C:           OS
#             RECOVERY
#D:           MYUSB
#             SYSTEM
#
#
#"""
  o = {}
  lines = [l for ll in cp.stdout.split(b"\n") for l in ll.split(b"\r")]
  for line in lines:
    m = re.match(b"^([A-Z]:|\\s{2})\\s{11}(.*)$", line)
    if not m: continue
    o[m.group(2).rstrip()] = m.group(1) if re.search(b"\\S", m.group(1)) else ""
  return o
