# PathLike_walk.py Version 1.0.0
# Copyright (c) 2023 <tnzw@github.triton.ovh>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

def PathLike_walk(top, topdown=True, followlinks=False):
  files = [];  dirs = []
  for child in top.iterdir():
    if not followlinks and child.is_symlink(): files.append(child)
    elif child.is_dir(): dirs.append(child)
    else: files.append(child)
  if topdown:
    yield top, dirs, files
    for child in dirs: yield from PathLike_walk(child, topdown=topdown, followlinks=followlinks)
  else:
    for child in dirs: yield from PathLike_walk(child, topdown=topdown, followlinks=followlinks)
    yield top, dirs, files
