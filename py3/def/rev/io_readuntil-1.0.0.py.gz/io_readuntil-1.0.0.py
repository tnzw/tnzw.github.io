# io_readuntil.py Version 1.0.0
# Copyright (c) 2021 Tristan Cavelier <t.cavelier@free.fr>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

def io_readuntil():
  # io_readuntil
  # io_readuntil.separators
  # io_readuntil.condition

  def rpartitionpart(bb, *seps):
    bbl = len(bb)
    sepsll = [len(sep) for sep in seps]
    for sepl in sepsll:
      if sepl <= 0: raise ValueError("empty separator")
    seps = list(zip(seps, sepsll))
    for i, ni in zip(range(bbl - 1, -1, -1), range(1, bbl + 1)):
      for sep, sepl in seps:
        isepl = sepl + i
        if bb[i:isepl] == sep[:ni]:
          return bb[:i], bb[i:isepl], bb[isepl:]
    return bb, bb[:0], bb[:0]

  def io_readuntil(reader, separator=b"\n"):
    """\
Read data from the stream until separator is found.

On success, the data and separator will be removed from the internal buffer
(consumed). Returned data will include the separator at the end.

If EOF is reached before the complete separator is found, an IncompleteReadError
exception is raised, and the internal buffer is reset. The
IncompleteReadError.partial attribute may contain a portion of the separator.
"""
    # https://docs.python.org/3/library/asyncio-stream.html#asyncio.StreamReader.readuntil
    len_sep = len(separator)
    if len_sep <= 0: raise ValueError("empty separator")
    def condition(data):
      d, s, remains = rpartitionpart(data, separator)  # `remains` should stay empty
      if s == separator: return 0
      return len_sep - len(s)
    return io_readuntil_condition(reader, condition, len_sep)

  def io_readuntil_separators(reader, separator, *separators):
    """\
Same but with multiple separators. Firsts separators have higher priority.
"""
    separators = (separator,) + separators
    min_len_sep = min(len(_) for _ in separators)
    if min_len_sep <= 0: raise ValueError("empty separator")
    def condition(data):
      d, s, remains = rpartitionpart(data, *separators)  # `remains` should stay empty
      if s in separators: return 0
      ms = min_len_sep - len(s)
      if ms > 0: return ms
      return 1
    return io_readuntil_condition(reader, condition, min_len_sep)

  def io_readuntil_condition(reader, condition, initial_read_size):
    """\
Read data from the reader until condition() returns 0.

`condition` should return a positive integer that will be used to read the next
chunk. It is called with one positional argument : a consolidation of read
chunks using the `+=` operator.
"""
    data = reader.read(initial_read_size)
    if not data: raise io_IncompleteReadError(data, initial_read_size)
    n = condition(data)
    if n <= 0: return data
    while True:
      d = reader.read(n)
      if not d: raise io_IncompleteReadError(data, len(data) + n)  # EOF but no boundary found
      data += d
      n = condition(data)
      if n <= 0: return data

  io_readuntil.separators = io_readuntil_separators
  io_readuntil.condition = io_readuntil_condition
  return io_readuntil

io_readuntil = io_readuntil()
io_readuntil._required_globals = ["io_IncompleteReadError"]
