# ntfstime_fromtimestamp.py Version 1.0.0
# Copyright (c) 2023 <tnzw@github.triton.ovh>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

def ntfstime_fromtimestamp(ts):
  # an ntfs time an amount of 100 nanoseconds since 1 Jan 1601
  ts = ts * 10000000
  ts = int(ts + 1) if ts % 1 else int(ts)
  return ts + 116444736000000000  # 116444736000000000 is "1 Jan 1970" - "1 Jan 1601" in 100ns
