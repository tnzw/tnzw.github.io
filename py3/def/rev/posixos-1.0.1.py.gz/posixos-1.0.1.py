# posixos.py Version 1.0.1
# Copyright (c) 2021 Tristan Cavelier <t.cavelier@free.fr>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

def posixos():
  class posixos(object):
    """\
A way to have the same `os` behavior as in a posix environment (like linux on windows)

with_drive_names => ("cygdrive",):
  Drives are place in /cygdrive/{letter.lower()} (eg /cygdrive/e for E:\\ on windows)
  You can set with_drive_names to () to have drives on root (eg /e for E:\\ on windows)
  Set to None, you cannot access drives.
  => None:  <no drive access>
  => (): /{letter.lower()}
  => ("mnt",): /mnt/{letter.lower()}
  => ("mnt", "drive"): /mnt/drive/{letter.lower()}

/!\\ On current implementation
  on windows: /cygdrive/e/../here -> E:\\..\\here.
"""
    def __init__(self, os_module=None, with_drive_names=("cygdrive",)):
      self._os = os_module
      self._with_drive_names = with_drive_names

    @property
    def os(self): return os if self._os is None else self._os

    # https://docs.python.org/3/library/os.html
    @property
    def curdir(self): return "."
    @property
    def pardir(self): return ".."
    @property
    def sep(self): return "/"
    @property
    def altsep(self): return None
    @property
    def extsep(self): return "."
    @property
    def pathsep(self): return ":"
    @property
    def linesep(self): return "\n"

    class path(object):
      # https://docs.python.org/3/library/os.path.html
      def __init__(self, os_module): self._os = os_module
      for _ in ("curdir", "pardir", "sep", "altsep", "extsep", "pathsep"):
        exec(f"@property\ndef {_}(self): return self._os.{_}", {}, locals())
      del _
      # The goal is to have a FULL posix like `os` on windows
      # original behavior on linux is :
      #   >>> ntpath.isdir("tmp")
      #   True
      #   >>> ntpath.isdir(".\\tmp")
      #   False  <- we want True
      # original behavior on window is :
      #   >>> posixpath.isdir("tmp")
      #   True
      #   >>> posixpath.isdir(".\\tmp")
      #   True  <- we want False
      for _ in ("basename", "commonpath", "commonprefix", "dirname", "isabs", "join",
                "normcase", "normpath", "split", "splitdrive", "splitext",
                "supports_unicode_filenames"):
        exec(f"@property\ndef {_}(self): return posixpath.{_}", globals(), locals())
      del _
      def abspath(self, path):
        path = self._os.fspath(path)
        if isinstance(path, str): return self.normpath(self.join(self._os.getcwd(), path))
        return self.normpath(self.join(self._os.getcwdb(), path))
      def expanduser(self, path):
        path = self._os.fspath(path)
        if self.isabs(path): return path
        tpath = self._os._translate_path(path, cast="tuplepath")
        if tpath.names:
          tpath = tpath.replace(path=self.os.path.expanduser(tpath.names[0]), os_module=self.os).extend(tpath[1:])
          return self._os._translate_path(tpath, reverse=True)
        return path
      def isfile(self, path):
        try: s = self._os.stat(path, _posixos_path_errors="none")
        except FileNotFoundError: return False
        if s: return stat.S_ISREG(s.st_mode)
        return False
      def isdir(self, path):
        try: s = self._os.stat(path, _posixos_path_errors="none")
        except FileNotFoundError: return False
        if s: return stat.S_ISDIR(s.st_mode)
        return False
      def islink(self, path):
        try: s = self._os.lstat(path, _posixos_path_errors="none")
        except FileNotFoundError: return False
        if s: return stat.S_ISLNK(s.st_mode)
        return False
      # ("exists", "lexists", "expandvars",
      #  "getatime", "getmtime", "getctime", "getsize",
      #  "ismount",
      #  "realpath", "relpath", "samefile", "sameopenfile", "samestat")

    def fspath(self, s): return self.os.fspath(s)
    # https://docs.python.org/3/library/sys.html#sys.getfilesystemencoding
    _filesystemencoding = "utf-8"  # actualy should be the locale encoding
    _filesystemencodeerrors = "surrogateescape"  # "surrogatepass" on windows
    def fsencode(self, filename):
      filename = self.fspath(filename)
      if isinstance(filename, str): return filename.encode(self._filesystemencoding, self._filesystemencodeerrors)
      return filename
    def fsdecode(self, filename):
      filename = self.fspath(filename)
      if isinstance(filename, bytes): return filename.decode(self._filesystemencoding, self._filesystemencodeerrors)
      return filename

    def _translate_path(self, path, reverse=False, *, cast=None):  #, errors="strict", default=None):
      if self.os.curdir != "." or self.os.pardir != "..": raise NotImplementedError("unhandled path mechanism")
      if reverse:  # fomr X to posix
        tpath = tuplepath(path, os_module=self.os)
        if self._with_drive_names not in (None, False) and tpath.fsencode().drivename.lower() in (_.encode() + b":" for _ in "abcdefghijklmnopqrstuvwxyz"):
          #tpath = tpath.replace(names=("mnt", tpath.drivename[:1].lower()) + tpath.names, os_module=self)
          #tpath = tpath.replace(names=(tpath.drivename[:1].lower(),) + tpath.names, os_module=self)
          tpath = tpath.replace(names=self._with_drive_names + (tpath.drivename[:1].lower(),) + tpath.names, os_module=self)
          tpath = tpath.replace(root=tpath.sep)
        else:
          tpath = tpath.replace(os_module=self)
        if cast == "tuplepath": return tpath
        return tpath.pathname
      else:  # from posix to X
        tpath = tuplepath(path, os_module=self).replace(os_module=self.os)
        seps = list(_ for _  in (tpath.sep, tpath.altsep) if _)
        for name in tpath.names:
          for sep in seps:
            if sep in name:
              raise ValueError("invalid path")
              #if errors == "strict": raise ValueError("invalid path")
              #elif errors == "default": return default
              #elif errors == "ignore": pass
              #else: raise LookupError(f"unknown error handler name {errors!r}")
        if self._with_drive_names not in (None, False) and tuplepath("A:\\", os_module=self.os).drivename == "A:":
          etpath = tpath.fsencode()
          l = len(self._with_drive_names)
          #if etpath[:1] == b"/mnt" and etpath[1:2].pathname in (_.encode() for _ in "abcdefghijklmnopqrstuvwxyz"):
          #if etpath.names and etpath.names[0] in (_.encode() for _ in "abcdefghijklmnopqrstuvwxyz"):
          if etpath[:l] == tuplepath(root="/", names=self._with_drive_names, os_module=self.os).fsencode() and b"".join(etpath.names[l:l+1]) in (_.encode() for _ in "abcdefghijklmnopqrstuvwxyz"):
            #rootname = tpath.names[1].upper()
            #rootname = tpath.names[0].upper()
            rootname = tpath.names[l].upper()
            rootname += b":\\" if isinstance(rootname, bytes) else ":\\"
            #tpath = tpath.replace(root=rootname, names=tpath.names[2:])
            #tpath = tpath.replace(root=rootname, names=tpath.names[1:])
            tpath = tpath.replace(root=rootname, names=tpath.names[l+1:])
        if cast == "tuplepath": return tpath
        return tpath.pathname

    def _call_pathorfd(self, *a, _posixos_path_errors="strict", **opt):
      method, path = a[:2]
      try:
        if not isinstance(path, int): path = self._translate_path(path)
      except ValueError:
        if _posixos_path_errors == "strict": raise
        elif _posixos_path_errors == "none": return None
        else: raise LookupError(f"unknown error handler name {_posixos_path_errors!r}")
      return getattr(self.os, method)(path, *a[2:], **opt)

    def stat(self, *a, **opt): return self._call_pathorfd("stat", *a, **opt)
    def lstat(self, *a, **opt): return self._call_pathorfd("lstat", *a, **opt)

    def _convert_open_flags(self, flags, os, *soft):
      if os.O_RDONLY != 0: raise NotImplementedError("cannot handle O_RDONLY != 0")
      new_flags = getattr(os, "O_BINARY", 0)
      for attr in "ACCMODE APPEND ASYNC CLOEXEC CREAT DIRECT DIRECTORY DSYNC EXCL LARGEFILE NDELAY NOATIME NOCTTY NOFOLLOW NONBLOCK PATH RDONLY RDWR RSYNC SYNC TMPFILE TRUNC WRONLY".split():
        selflag = getattr(self, "O_" + attr)
        new_flags |= getattr(os, "O_" + attr, *soft) if (flags & selflag) == selflag else 0
      return new_flags

    O_ACCMODE = 3
    O_APPEND = 1024
    O_ASYNC = 8192
    O_CLOEXEC = 524288
    O_CREAT = 64
    O_DIRECT = 16384
    O_DIRECTORY = 65536
    O_DSYNC = 4096
    O_EXCL = 128
    O_LARGEFILE = 0
    O_NDELAY = 2048
    O_NOATIME = 262144
    O_NOCTTY = 256
    O_NOFOLLOW = 131072
    O_NONBLOCK = 2048
    O_PATH = 2097152
    O_RDONLY = 0
    O_RDWR = 2
    O_RSYNC = 1052672
    O_SYNC = 1052672
    O_TMPFILE = 4259840
    O_TRUNC = 512
    O_WRONLY = 1

    def open(self, path, flags, *a, **opt):
      flags = self._convert_open_flags(flags, self.os, 0)
      return self.os.open(path, flags, *a, **opt)

    #def listdir(self, path="."):
    #  if isinstance(path, int): return self.os.listdir(path)
    #  if self._with_drive_names not in (None, False) and tuplepath("A:\\", os_module=self.os).drivename == "A:":
    #    if tuplepath(path, os_module=self).fsencode() == tuplepath(root="/", names=self._with_drive_names, os_module=self.os).fsencode():
    #      return XXX list all drives!?
    #  path = self._translate_path(path)
    #  return self.os.listdir(path)

    # XXX do other methods
    # XXX mkdir: windows cannot replace an empty dir with another dir, linux can.
    #            can linux replace an empty dir with a file?

  posixos = posixos()
  posixos.path = posixos.path(posixos)
  return posixos
posixos = posixos()
posixos._required_globals = ["os", "os_fspath", "tuplepath"]
