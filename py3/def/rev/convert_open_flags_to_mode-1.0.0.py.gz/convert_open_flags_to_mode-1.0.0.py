# convert_open_flags_to_mode.py Version 1.0.0
# Copyright (c) 2020 Tristan Cavelier <t.cavelier@free.fr>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

def convert_open_flags_to_mode(flags, use_t=False, os_module=None):  # XXX test it !
  if os_module is None: os_module = os
  trunc = 1 if flags & os_module.O_TRUNC else 0
  if trunc: raise ValueError("invalid flags")
  rdonly = 1 if flags & os_module.O_RDONLY else 0
  wronly = 1 if flags & os_module.O_WRONLY else 0
  rdwr = 1 if flags & os_module.O_RDWR else 0
  if rdonly + wronly + rdwr != 1: raise ValueError("invalid flags")
  creat = 1 if flags & os_module.O_CREAT else 0
  excl = 1 if flags & os_module.O_EXCL else 0
  append = 1 if flags & os_module.O_APPEND else 0
  if excl + append not in (0, 1): raise ValueError("invalid flags")

  binary = "b" if flags & os_module.O_BINARY else ("t" if use_t else "")
  rdwr = "+" if rdwr else ""

  if (wronly or rdwr) and creat and append: return "a" + rdwr + binary
  if (wronly or rdwr) and creat and excl: return "x" + rdwr + binary
  if (wronly or rdwr) and creat: return "w" + rdwr + binary
  if (rdonly or rdwr): return "r" + rdwr + binary
  raise ValueError("invalid flags")

convert_open_flags_to_mode._required_globals = ["os"]
