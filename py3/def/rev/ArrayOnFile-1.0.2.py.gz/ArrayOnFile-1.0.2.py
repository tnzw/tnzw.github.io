# ArrayOnFile.py Version 1.0.2
# Copyright (c) 2021 Tristan Cavelier <t.cavelier@free.fr>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

class ArrayOnFile(tuple):
  # (indices, fileno, os_module, opts)
  # extending tuple is just a way to make ArrayOnFile an immutable object
  # usage:
  #   with ArrayOnFile.open("path") as fa:
  #     # ...

  # inspired by bytearray (without the operations that change its length)

  # >>> dir(bytearray(0))
  # ['__add__', '__alloc__', '__class__', '__contains__', '__delattr__',
  #  '__delitem__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__',
  #  '__getattribute__', '__getitem__', '__gt__', '__hash__', '__iadd__',
  #  '__imul__', '__init__', '__init_subclass__', '__iter__', '__le__',
  #  '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__',
  #  '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__',
  # '__setattr__', '__setitem__', '__sizeof__', '__str__', '__subclasshook__',
  # 'append', 'capitalize', 'center', 'clear', 'copy', 'count', 'decode',
  # 'endswith', 'expandtabs', 'extend', 'find', 'fromhex', 'hex', 'index',
  # 'insert', 'isalnum', 'isalpha', 'isascii', 'isdigit', 'islower', 'isspace',
  # 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'maketrans',
  # 'partition', 'pop', 'remove', 'removeprefix', 'removesuffix', 'replace',
  # 'reverse', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip',
  # 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title',
  # 'translate', 'upper', 'zfill']

  # >>> dir(())
  # ['__add__', '__class__', '__class_getitem__', '__contains__', '__delattr__',
  #  '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__',
  #  '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__',
  #  '__init_subclass__', '__iter__', '__le__', '__len__', '__lt__', '__mul__',
  #  '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmul__',
  #  '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'count',
  #  'index']

  @staticmethod
  def open(path, mode="rw", os_module=None):
    # mode could be "ro", "wo" or "rw" + some of `open(..., mode)` syntax
    def _or(iterable):
      r = 0
      for _ in iterable: r |= _
      return r
    if os_module is None: os_module = os
    mode = "".join(sorted(mode))
    # force opening with o_binary to avoid side effects.
    if   mode in ("rw",):           flags = ("O_RDWR", "O_BINARY") #, "O_CREAT")  # we want an existing file as an array, so don't o_creat.
    elif mode in ("r", "or", "br"): flags = ("O_RDONLY", "O_BINARY")
    #elif mode in ("w", "ow", "bw"): flags = ("O_WRONLY", "O_BINARY") #, "O_CREAT", "O_TRUNC")  # we want an existing file as an array, so don't o_creat or o_trunc.
    elif mode in ("+r", "+br"):     flags = ("O_RDWR", "O_BINARY")
    #elif mode in ("+w", "+bw"):     flags = ("O_RDWR", "O_BINARY") #, "O_CREAT", "O_TRUNC")  # same
    else: raise ValueError(f"unhandled mode {mode!r}")
    return ArrayOnFile(os_module.open(path, _or(getattr(os_module, _, 0) for _ in flags)), os_module=os_module)

  @staticmethod
  def indices__len__(indices):
    start, stop, step = indices
    if step < 0:
      delta = start - stop
      if step < 1:
        d,m = divmod(delta, -step)
        delta = d + (1 if m else 0)
    else:
      delta = stop - start
      if step > 1:
        d,m = divmod(delta, step)
        delta = d + (1 if m else 0)
    return delta if delta > 0 else 0

  @staticmethod
  def indices__getitem__(indices, key):
    if isinstance(key, slice): is_slice = True
    else: is_slice, key = False, slice(key, key + 1, 1)
    size = ArrayOnFile.indices__len__(indices)
    if not is_slice and (key.start >= size or key.start < -size):
      raise IndexError("index is out of range")
    start, stop, step = key.indices(size)
    sstart, sstop, sstep = indices
    sneg = sstep < 0
    kneg = step < 0
    if sneg:
      ssize = max(sstart - sstop, 0)
      mod = ssize % sstep
      step *= sstep
      start = sstart + start * sstep
      if kneg:
        stop = sstart + stop * sstep + mod
      else:
        stop = sstart + stop * sstep - mod
        if stop < 0: stop = None
    else:
      ssize = max(sstop - sstart, 0)
      mod = ssize % sstep
      step *= sstep
      start = sstart + start * sstep
      if kneg:
        stop = sstart + stop * sstep + mod
        if stop < 0: stop = None
      else:
        stop = sstart + stop * sstep - mod
    if is_slice: return slice(start, stop, step)
    return start

  @property
  def indices(self):
    start, stop, step = tuple.__getitem__(self, 0)
    if step < 0:
      # never happens
      if start is None: start = self._os.lseek(self.fileno, 0, self._os.SEEK_END) - 1
    else:
      if stop is None: stop = self._os.lseek(self.fileno, 0, self._os.SEEK_END)
    return start, stop, step
  @property
  def  fileno(self): return tuple.__getitem__(self, 1)
  @property
  def     _os(self): return tuple.__getitem__(self, 2)
  @property
  def    opts(self): return tuple.__getitem__(self, 3)

  def __new__(cls, fileno, slice_key=None, *, os_module=None):
    if os_module is None: os_module = os
    if slice_key is None: return tuple.__new__(cls, ((0, None, 1), fileno, os_module))
    #if slice_key is None: slice_key = slice(0, None, 1)
    size = os_module.lseek(fileno, 0, os_module.SEEK_END)
    start, stop, step = slice_key.indices(size)
    return tuple.__new__(cls, ((start, stop, step), fileno, os_module))

  def is_slice(self):
    start, stop, step = tuple.__getitem__(self, 0)
    if step < 0: return start is not None
    return stop is not None

  #def __del__(self): close? NO! 'cause __getitem__ creates new instances so previous ones are deleted!
  #                   it would work if `fileno` could have a __del__.
  def __enter__(self): return self
  def __exit__(self, *a): self._os.close(self.fileno)

  def __len__(self): return self.indices__len__(self.indices)

  def iter(self, buffer_size=4096): return self.__iter__(buffer_size=buffer_size)
  def __iter__(self, buffer_size=4096):  # XXX buffer_size is a bit hardcoded
    # without O_BINARY flag on windows, you may have different amount of data than "size" told you...
    start, stop, step = self.indices
    length = self.indices__len__((start, stop, step))
    if length <= 0: return
    os, fd = self._os, self.fileno
    SEEK_SET, SEEK_CUR = os.SEEK_SET, os.SEEK_CUR
    if step < 0:
      start += 1
      stride, chunk, extra_step = 1, b"", 0
      if step < 1: length = (length - 1) * -step + 1
      while stride:
        if step < 1:
          for c in chunk[::-1]:
            if extra_step == 0:
              yield c  # ouch, big inconsistency here without O_BINARY flag!
              extra_step = -step - 1
            else:
              extra_step -= 1
        else:
          for c in chunk[::-1]:
            yield c
        stride, desired_stride = 0, min(buffer_size, length)
        while stride != desired_stride:
          s = os.lseek(fd, start - desired_stride + stride, SEEK_SET)
          chunk += os.read(fd, desired_stride - stride)
          stride += os.lseek(fd, 0, SEEK_CUR) - s  # `stride += len(chunk)` isn't correct on windows without O_BINARY flag.
        length -= stride
        start -= stride
    else:
      stride, chunk, extra_step = 1, b"", 0
      if step > 1: length = (length - 1) * step + 1
      while stride:
        if step > 1:
          for c in chunk:
            if extra_step == 0:
              yield c  # ouch, big inconsistency here without O_BINARY flag!
              extra_step = step - 1
            else:
              extra_step -= 1
        else:
          for c in chunk:
            yield c
        s = os.lseek(fd, start, SEEK_SET)
        chunk = os.read(fd, min(buffer_size, length))
        stride = os.lseek(fd, 0, SEEK_CUR) - s  # `stride += len(chunk)` isn't correct on windows without O_BINARY flag.
        length -= stride
        start += stride

  def __contains__(self, item):
    for _ in self:
      if _ == item: return True
    return False

  def __eq__(self, other):  # XXX is it really optimised ?
    if len(self) != len(other): return False
    for a, b in zip(self, other):
      if a != b: return False
    return True
  def __ne__(self, other):
    return not(self == other)
  def __gt__(self, other):
    s, o = iter(self), iter(other)
    for a, b in zip(s, o):
      if a < b: return False
      if a > b: return True
    try: next(s)
    except StopIteration: pass
    else: return True
    try: next(o)
    except StopIteration: pass
    else: return False
    return False
  def __ge__(self, other):
    s, o = iter(self), iter(other)
    for a, b in zip(s, o):
      if a < b: return False
      if a > b: return True
    try: next(s)
    except StopIteration: pass
    else: return True
    try: next(o)
    except StopIteration: pass
    else: return False
    return True
  def __lt__(self, other):
    s, o = iter(self), iter(other)
    for a, b in zip(s, o):
      if a < b: return True
      if a > b: return False
    try: next(s)
    except StopIteration: pass
    else: return False
    try: next(o)
    except StopIteration: pass
    else: return True
    return False
  def __le__(self, other):
    s, o = iter(self), iter(other)
    for a, b in zip(s, o):
      if a < b: return True
      if a > b: return False
    try: next(s)
    except StopIteration: pass
    else: return False
    try: next(o)
    except StopIteration: pass
    else: return True
    return True

  def __array__(self): return bytes(self)

  def __repr__(self): return self.__class__.__name__ + "(" + repr(self.fileno) + ", " + repr(slice(*self.indices)) + ")"
  #def __repr__(self): return self.__class__.__name__ + " [" + ",".join(repr(_) for _ in self) + "]"

  def __str__(self):
    M, S = 60, "..."
    SL = len(S)
    s = repr(bytes(self[:M + 1]))
    if len(s) > M: s = s[:M - SL] + S
    return self.__class__.__name__ + " " + s

  def __getitem__(self, key):
    key = self.indices__getitem__(self.indices, key)
    if isinstance(key, slice):
      return self.__class__(self.fileno, key)
    os, fd = self._os, self.fileno
    os.lseek(fd, key, os.SEEK_SET)
    return os.read(fd, 1)[0]

  def __iadd__(self, other):
    if self.is_slice(): raise ValueError("cannot append on a slice")
    if not isinstance(other, (bytes, bytearray)): other = bytes(other)
    itemlen = len(other)
    os, fd = self._os, self.fileno
    os.lseek(fd, 0, os.SEEK_END)
    written = 0
    while written < itemlen:
      w = os.write(fd, other[written:])
      if w == 0: break
      written += w
    return self

  def __imul__(self, other):
    if self.is_slice(): raise ValueError("cannot append on a slice")
    if not isinstance(other, int): raise TypeError("can't multiply sequence by non-int")
    os, fd = self._os, self.fileno
    if other < 1:
      os.ftruncate(fd, 0)
      return self
    SEEK_END = os.SEEK_END
    l = os.lseek(fd, 0, SEEK_END)
    copy_file_range = getattr(os, "copy_file_range", os_copy_file_range)
    try: copy_file_range(fd, fd, 0, 0, 0)  # test the method
    except OSError as e:
      if e.errno != errno.ENOSYS: raise  # hm… I wish I had no try…except.
      copy_file_range = os_copy_file_range
    for i in range(1, other, 1):
      copy_file_range(fd, fd, l, 0, l * i)
    return self

  def __setitem__(self, key, item):
    key = self.indices__getitem__(self.indices, key)
    os, fd = self._os, self.fileno
    if isinstance(key, slice):
      if not isinstance(item, (bytes, bytearray)): item = bytes(item)
      itemlen = len(item)
      #start, stop, step = key.indices(os.lseek(fd, 0, os.SEEK_END))
      start, stop, step = key.start, key.stop, key.step
      if stop is None: stop = -1
      deslen = self.indices__len__((start, stop, step))
      resize = 0
      if step == 1 and not self.is_slice() and stop == len(self):
        # allow to write more or less (with truncate if necessary)
        resize = itemlen - deslen
      else:
        if itemlen < deslen: raise ValueError(f"not enough values to unpack (expected {deslen})")
        if itemlen > deslen: raise ValueError(f"too many values to unpack (expected {deslen})")
      if step == 1:
        os.lseek(fd, start, os.SEEK_SET)
        written = 0
        while written < itemlen:
          w = os.write(fd, item[written:])
          if w == 0: break
          written += w
      elif step == -1:
        item = item[::-1]
        os.lseek(fd, stop + 1, os.SEEK_SET)
        written = 0
        while written < itemlen:
          w = os.write(fd, item[written:])
          if w == 0: break
          written += w
      else:
        for i, v in zip(range(start, stop, step), item):
          os.lseek(fd, i, os.SEEK_SET)
          os.write(fd, bytes((v,))[:1])
      if resize < 0: os.truncate(fd, os.lseek(fd, 0, os.SEEK_CUR))
      return
    os.lseek(fd, key, os.SEEK_SET)
    os.write(fd, bytes((item,))[:1])

ArrayOnFile._required_globals = ["errno", "os_copy_file_range"]
