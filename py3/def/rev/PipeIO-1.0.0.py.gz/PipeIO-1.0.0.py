# PipeIO.py Version 1.0.0
# Copyright (c) 2021 Tristan Cavelier <t.cavelier@free.fr>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

class PipeIO(object):

  for _ in ("__iter__", "__next__", "readline", "readlines"):
    exec(f"def {_}(self, *a, **k): return RawIOBase.{_}(self, *a, **k)", globals(), locals())
  del _

  def __init__(self, raw=None):
    self.raw = bytearray() if raw is None else raw

  def readable(self): return True

  def readinto1(self, b):
    l = min(len(self.raw), len(b))
    b[:l], self.raw[:] = self.raw[:l], self.raw[l:]
    return l

  def read1(self, size=-1):
    if size is None or size < 0:
      d, self.raw[:] = self.raw[:], ()
    else:
      d, self.raw[:] = self.raw[:size], self.raw[size:]
    return d

  def readall(self):
    d, self.raw[:] = self.raw[:], ()
    return d

  def readinto(self, b): return self.readinto(b)
  def read(self, size=-1): return self.read1(size)

  def seekable(self): return False

  def write(self, b):
    lr, lb = len(self.raw), len(b)
    self.raw[lr:] = b
    return lb
  def writable(self): return True
