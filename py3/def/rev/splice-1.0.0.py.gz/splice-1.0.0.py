# splice.py Version 1.0.0
# Copyright (c) 2021 Tristan Cavelier <t.cavelier@free.fr>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

def splice(*array_slice_replacement):
  """\
splice(array[, start[, stop[, replacement]]])
splice(array[, slice_key[, replacement]])
"""
  replacement = ()
  l = len(array_slice_replacement)
  if l > 4:
    raise TypeError(f"splice() expected at most 4 arguments, got {l}")
  elif l == 4:
    array, start, stop, replacement = array_slice_replacement
    key = slice(start, stop)
  elif l == 3:
    array, start, stop = array_slice_replacement
    if isinstance(start, slice): key, replacement = start, stop
    else: key = slice(start, stop)
  elif l == 2:
    array, start = array_slice_replacement
    if isinstance(start, slice): key = start
    else: key = slice(start, None)
  elif l == 1:
    array, = array_slice_replacement
    key = slice(None)
  else:
    raise TypeError(f"splice() expected at least 1 argument, got {l}")
  chunk, array[key] = array[key], replacement
  return chunk
