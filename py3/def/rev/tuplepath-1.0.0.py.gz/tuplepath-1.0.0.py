# tuplepath.py Version 1.0.0
# Copyright (c) 2020 Tristan Cavelier <t.cavelier@free.fr>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

class tuplepath(object):
  # https://docs.python.org/fr/3/library/os.path.html
  _pathname = None  # cache for normalizing types and joining self.tuple, we should not override encoding / fsdecode should not change behavoir
  def __init__(self, path="", os_module=None):
    self.os = os if os_module is None else os_module
    #self.encoding = (encoding,) if isinstance(encoding, str) else encoding
    if not path: self.tuple = (b"",) if isinstance(path, bytes) else ("",)
    elif isinstance(path, tuple): self.tuple = path
    else: self.tuple = os_path_split(path, -1, os_module=self.os)
  # https://docs.python.org/3/reference/datamodel.html
  def __repr__(self):
    #repr_encoding = "" if self.encoding is None else f", encoding={self.encoding!r}"
    repr_os = "" if self.os is os else f", os_module={self.os!r}"
    return self.__class__.__name__ + f"({self.tuple!r}{repr_os})"
  def __str__(self): return str(self.pathname)
  def __bytes__(self): return self.pathname if isinstance(self.rootname, bytes) else self.fsencode().pathname
  def __eq__(self, path): return self.tuple == self._new(path).tuple
  def __bool__(self):
    for _ in self.tuple:
      if _: return True
    return False
  def __len__(self): return len(self.names)
  def __getitem__(self, key):
    if isinstance(key, slice):
      if key.start in (0, None): return self._new((self.rootname,) + self.names[key])
      return self._new((self.emptyname,) + self.names[key])
    return self.names[key]
  def __iter__(self): return self.names.__iter__()
  def __add__(self, other):
    # kind of act like str/bytes __add__ -> tuplepath("C:/a") + "D:/b" -> "C:/a/D:/b"
    # use join for such a result -> tuplepath("C:/a").join("D:/b") -> "D:/b"
    other = self._new(other)
    if not other: return self._new(self.tuple)
    drivename = other.drivename
    return self._new((self.rootname,) + self.names + ((drivename,) if drivename else ()) + other.names)
  def __radd__(self, other):
    # kind of act like str/bytes __radd__ -> "D:/b" + tuplepath("C:/a") -> "D:/b/C:/a"
    other = self._new(other)
    if not other: return self._new(self.tuple)
    drivename = self.drivename
    return self._new(other.tuple + ((drivename,) if drivename else ()) + self.names)
  def __fspath__(self): return self.pathname
  def _new(self, path=""): return self.__class__(path, os_module=self.os)

  for _ in "sep altsep curdir pardir pathsep extsep".split():
    exec(f"""@property\ndef {_}(self):\n if isinstance(self.rootname, bytes): return self.os.fsencode(self.os.path.{_})\n return self.os.path.{_}\n""", globals(), locals())
  del _

  @property
  def rootname(self): return self.tuple[0] if self.tuple else ""
  @property
  def names(self): return self.tuple[1:]
  @property
  def dirname(self): return self.dir().pathname
  @property
  def basename(self): return self.names[-1] if self.names else self.emptyname
  @property
  def extname(self): return self.splitext()[1]
  @property
  def drivename(self): return self.splitdrive()[0]
  @property
  def pathname(self):
    if self._pathname is None:
      p = self.normtype()
      self._pathname = p.rootname + p.sep.join(p.names)
    return self._pathname
  @property
  def emptyname(self): return self.rootname[:0]

  def commonpath(self, paths):
    # it normaly raises when types are mixed : TypeError: Can't mix strings and bytes in path component
    common_tuple = ()
    paths = tuple(self._new(_).tuple for _ in paths)
    for _ in zip(*(self.tuple,) + paths):
      for i in range(len(_) - 1):
        if _[i] != _[i + 1]: break
      else: 
        common_tuple = common_tuple + (_[0],)
        continue
      break
    if common_tuple: return self._new(common_tuple)
    raise ValueError("Can't mix absolute and relative paths or paths don't have the same drive")

  def dir(self): return self._new((self.rootname,) + self.names[:-1])

  def fsdecode(self):
    if not isinstance(self.rootname, bytes): return self.normtype()
    return self._new(tuple(self.os.fsdecode(name) for name in (self.rootname,) + self.names))  # copied from normtype below

  def fsencode(self):
    if isinstance(self.rootname, bytes): return self.normtype()
    return self._new(tuple(self.os.fsencode(name) for name in (self.rootname,) + self.names))  # copied from normtype below

  def isabs(self): return True if self.rootname else False

  def join(self, *pathes):
    new = self.tuple
    for path in pathes:
      for i in range(len(new) - 1, 0, -1):
        if not new[i]: new = new[:-1]
      path = self._new(path)
      if path.isabs(): new = path.tuple
      else: new = new + path.names
    return self._new(new)

  def norm(self):
    rootname = self.rootname
    if self.altsep: rootname = rootname.replace(self.altsep, self.sep)
    names = ()
    for name in self.names:
      if not name or name in (".", b".", "", b""): pass
      elif name in ("..", b".."):
        if not rootname and (names and names in (("..",), (b"..",)) or not names): names = names + (name,)
        else: names = names[:-1]
      else:
        if self.altsep: name = name.replace(self.altsep, self.sep)
        names = names + tuple(name.split(self.sep))
    return self._new((rootname,) + names)

  normpath = norm

  def normtype(self):
    if isinstance(self.rootname, bytes):
      return self._new(tuple(self.os.fsencode(name) for name in (self.rootname,) + self.names))
    return   self._new(tuple(self.os.fsdecode(name) for name in (self.rootname,) + self.names))
    #if isinstance(self.rootname, bytes):
    #  return self._new((self.rootname, *(name if isinstance(name, bytes) else name.encode(*self.encoding[:1]) for name in self.names)))
    #return self._new((self.rootname, *(name if isinstance(name, str) else name.decode(*self.encoding[:2]) for name in self.names)))

  def root(self, root): return self._new((root,) + self.names)

  def sibling(self, *paths): return self.dir().join(*paths)

  def split(self): return self.dirname, self.basename

  def splitdrive(self):
    drive, rootname = self.os.path.splitdrive(self.rootname)
    return drive, self._new((rootname,) + self.names)  # this might be changed to relative path, as original os.path.splidrive can do

  def splitext(self):
    basename = self.basename
    l = -1
    for i,c in enumerate(basename):
      if c in (".", b".", 0x2e): l = i
    if l <= 0: return basename, basename[:0]
    return basename[:i], basename[i:]

tuplepath._required_globals = ["os", "os_path_split"]
