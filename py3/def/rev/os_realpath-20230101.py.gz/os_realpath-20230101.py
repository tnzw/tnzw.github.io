# Version 20230101
# algorithm copied from posixpath.py (python 3.11)
# see https://github.com/python/cpython/blob/3.11/Lib/posixpath.py#L412

def os_realpath(path, *, strict=False, os_module=None):
  """Return the canonical path of the specified filename, eliminating any symbolic links encountered in the path."""
  if os_module is None: os_module = os
  path = os_module.fspath(path)
  path, ok = os_joinrealpath(os_module.getcwdb() if isinstance(path, bytes) else os_module.getcwd(), path, strict=strict, os_module=os_module)
  return path
os_realpath._required_globals = ['os', 'os_joinrealpath']
