# PipeIO.py Version 1.1.0
# Copyright (c) 2021 Tristan Cavelier <t.cavelier@free.fr>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

class PipeIO(object):
  # io.IOBase
  #   mixins ["close", "closed", "__enter__", "__exit__", "flush", "isatty",
  #           "__iter__", "__next__", "readable", "readline", "readlines",
  #           "seekable", "tell", "writable", "writelines"]
  #   stubs  ["fileno", "seek", "truncate"]

  for _ in ("__enter__", "__exit__", "flush", "isatty",
            "__iter__", "__next__", "readline", "readlines", "writelines",
            "fileno", "_checkClosed"):
    exec(f"def {_}(self, *a, **k): return RawIOBase.{_}(self, *a, **k)", globals(), locals())
  del _

  # io.RawIOBase
  #   mixins IOBase + ["read", "readall"]
  #   stubs  ["readinto", "write"]
  #   others ["raw"]

  # io.BufferedIOBase
  #   mixins IOBase + ["readinto", "readinto1"]
  #   stubs  ["detach", "read", "read1", "write"]
  #   others ["buffer"]

  @property
  def closed(self): return self.raw is None
  def close(self): self.raw = None

  def __init__(self, raw=None): self.raw = bytearray() if raw is None else raw

  def peek(self, size=-1):
    self._checkClosed()
    if size is None or size < 0: return self.raw[:]
    return self.raw[:size]

  def readable(self): return True

  def readinto1(self, b):
    self._checkClosed()
    l = min(len(self.raw), len(b))
    b[:l], self.raw[:] = self.raw[:l], self.raw[l:]
    return l

  def read1(self, size=-1):
    self._checkClosed()
    if size is None or size < 0:
      d, self.raw[:] = self.raw[:], ()
    else:
      d, self.raw[:] = self.raw[:size], self.raw[size:]
    return d

  def readall(self):
    self._checkClosed()
    d, self.raw[:] = self.raw[:], ()
    return d

  def readinto(self, b): return self.readinto1(b)
  def read(self, size=-1): return self.read1(size)

  def seekable(self): return False

  def lwrite(self, b):
    self._checkClosed()
    lb = len(b)
    self.raw[:0] = b
    return lb

  def write(self, b):
    self._checkClosed()
    lr, lb = len(self.raw), len(b)
    self.raw[lr:] = b
    return lb

  def writable(self): return True
