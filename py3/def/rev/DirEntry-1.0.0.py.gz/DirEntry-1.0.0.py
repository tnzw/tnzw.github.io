# DirEntry.py Version 1.0.0
# Copyright (c) 2021 Tristan Cavelier <t.cavelier@free.fr>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

class DirEntry(object):
  # /!\ Be careful! It does not follow chdir calls!!
  __slots__ = ("name", "path", "os", "_lstat", "_stat")
  def __init__(self, path=None, *, name=None, os_module=None, _lstat=None, _stat=None):
    self.path = path
    self.os = os if os_module is None else os_module
    self.name = self.os.path.basename(path) if name is None else name
    self._lstat = _lstat
    self._stat = _stat
  def inode(self): return self.stat(follow_symlinks=False).st_ino
  def is_dir(self, *, follow_symlinks=True): return stat.S_ISDIR(self.stat(follow_symlinks=follow_symlinks).st_mode)
  def is_file(self, *, follow_symlinks=True): return stat.S_ISREG(self.stat(follow_symlinks=follow_symlinks).st_mode)
  def is_symlink(self): return stat.S_ISLNK(self.stat(follow_symlinks=False).st_mode)
  def stat(self, *, follow_symlinks=True):
    if follow_symlinks:
      if self._stat: return self._stat
      self._stat = self.os.stat(self.path, follow_symlinks=True)
      return self._stat
    if self._lstat: return self._lstat
    self._lstat = self.os.stat(self.path, follow_symlinks=False)
    return self._lstat
