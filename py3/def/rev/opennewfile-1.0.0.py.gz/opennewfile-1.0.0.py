# opennewfile.py Version 1.0.0
# Copyright (c) 2018-2020 Tristan Cavelier <t.cavelier@free.fr>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

# Requires : os
def opennewfile(path, mode="wx", **opt):
  """\
opennewfile(path, **opt) -> (file_handle, new_path)
  opt
    baseformat => (b)"%(name)s_%(index)d%(extension)s"
    other args are the same as the 'open' builtin
"""
  if "baseformat" not in opt:
    baseformat = b"%(name)s_%(index)d%(extension)s" if isinstance(path, bytes) else "%(name)s_%(index)d%(extension)s"
  else:
    baseformat = opt["baseformat"]
  if "opener" in opt: raise NotImplementedError
  if "r" in mode or "a" in mode: raise ValueError("invalid mode: " + repr(mode))
  if "w" not in mode: mode += "w"
  if "x" not in mode: mode += "x"
  try:
    f = open(path, mode, **opt)
  except OSError as e:
    if e.errno != errno.EEXIST: raise
  else:
    return f, path
  dir, base = os.path.split(path)
  name, ext = os.path.splitext(base)
  format_dict = {
    "b": base,
    "base": base,
    "basename": base,
    "n": name,
    "name": name,
    "i": 0,
    "index": 0,
    "e": ext,
    "ext": ext,
    "extension": ext,
  }
  format_dict.update({k.encode("ascii"): v for k, v in format_dict.items()})
  check_format = baseformat % format_dict  # cannot use str.format with bytes
  format_dict["index"] += 1
  format_dict["i"] += 1
  format_dict[b"index"] += 1
  format_dict[b"i"] += 1
  if check_format == baseformat % format_dict:
    raise ValueError("baseformat should at least contain '%(index)d'")
  while 1:
    new_path = os.path.join(dir, baseformat % format_dict)
    try:
      f = open(new_path, mode, **opt)
    except OSError as e:
      if e.errno != errno.EEXIST: raise
      format_dict["index"] += 1
      format_dict["i"] += 1
      format_dict[b"index"] += 1
      format_dict[b"i"] += 1
    else:
      return f, new_path
