# pathhelper.py Version 1.0.0
# Copyright (c) 2020 Tristan Cavelier <t.cavelier@free.fr>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

class pathhelper(object):
  # https://docs.python.org/fr/3/library/os.path.html
  _tuple = None  # cache for spliting pathname
  def __init__(self, path="", normpath=False, os_module=None):
    self.os = os if os_module is None else os_module
    self.pathname = self.os.fspath(path)
    if normpath: self.pathname = self.os.path.normpath(self.pathname)
  # https://docs.python.org/3/reference/datamodel.html
  def __repr__(self):
    repr_os = "os" if self.os is os else repr(self.os)
    return self.__class__.__name__ + f"({self.pathname!r}, os_module={repr_os})"
  def __str__(self): return str(self.pathname)
  def __bytes__(self): return self.pathname if isinstance(self.pathname, bytes) else self.fsencode().pathname
  def __eq__(self, path): return self.pathname == (path.pathname if isinstance(path, self.__class__) else path)
  def __bool__(self): return True if self.pathname else False
  def __len__(self): return len(self.pathname)
  def __getitem__(self, key):
    if isinstance(key, slice):
      if key.start in (0, None): return self._new((self.rootname,) + self.names[key])
      return self._new((self.emptyname,) + self.names[key])
    return self.names[key]
  def __iter__(self): return iter(self.names)
  def __add__(self, other):
    other = self._new(other)
    if not other: return self.pathname
    return self.pathname + (self.emptyname if self.pathname[-1:] in (self.sep, self.altsep) or other.pathname[:1] in (self.sep, self.altsep) else self.sep) + other.pathname
  def __radd__(self, other):
    other = self._new(other)
    if not other: return self.pathname
    return other.pathname + (self.emptyname if other.pathname[-1:] in (self.sep, self.altsep) or self.pathname[:1] in (self.sep, self.altsep) else self.sep) + self.pathname
  def __fspath__(self): return self.pathname
  def _new(self, path=""): return self.__class__(path, os_module=self.os)
  @property
  def tuple(self):
    if self._tuple is None: self._tuple = os_path_split(self.pathname, -1, os_module=self.os)
    return self._tuple

  for _ in "sep altsep curdir pardir pathsep extsep".split(): exec(f"""@property\ndef {_}(self):\n  return self.os.fsencode(self.os.path.{_}) if isinstance(self.pathname, bytes) else self.os.path.{_}\n""", globals(), locals())
  for _ in "isabs".split(): exec(f"""def {_}(self, *a, **k):\n  return self.os.path.{_}(self.pathname, *a, **k)\n""", globals(), locals())
  for _ in "basename dirname".split(): exec(f"""@property\ndef {_}(self):\n  return self._new(self.os.path.{_}(self.pathname))\n""", globals(), locals())
  for _ in "normcase normpath join".split(): exec(f"""def {_}(self, *a, **k):\n  return self._new(self.os.path.{_}(self.pathname, *a, **k))\n""", globals(), locals())
  for _ in "split splitdrive splitext".split(): exec(f"""def {_}(self, *a, **k):\n  _ = self.os.path.{_}(self.pathname, *a, **k)\n  return self._new(_[0]), self._new(_[1])\n""", globals(), locals())
  def commonpath(self, paths): return self.os.path.commonpath((self.pathname, *paths))

  for _ in "fsdecode fsencode".split(): exec(f"""def {_}(self, *a, **k):\n  return self._new(self.os.{_}(self.pathname, *a, **k))\n""", globals(), locals())
  for _ in "chmod chown stat lchmod lchown lstat utime truncate".split(): exec(f"""def {_}(self, *a, **k):\n  return self.os.{_}(self.pathname, *a, **k)\n""", globals(), locals())
  del _

  norm = normpath
  @property
  def extname(self): return self.splitext()[1]
  @property
  def rootname(self):
    path = self.pathname[:4] # avoid using too much aplit()
    return self._new(os_path_split(path, -1, os_module=self.os)[0])
  @property
  def drivename(self): return self.splitdrive()[0]
  @property
  def emptyname(self): return self.pathname[:0]
  def sibling(self, *paths):
    # "a/b/c".sibling("d") -> "a/b/d"
    #  "a/b/".sibling("d") -> "a/b/d"
    _ = self.os.path.split(self.pathname)
    return self._new(self.os.path.join(_[0], *paths))

pathhelper._required_globals = ["os", "os_path_split"]
