# open2.py Version 1.0.0
# Copyright (c) 2021 Tristan Cavelier <t.cavelier@free.fr>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

def open2(path, mode="rb", os_module=None):
  """\
Uses `os.fdopen` to open file, instead of using buitin `open`.
"""
  if os_module is None: os_module = os
  fd = None
  try:
    fd = os_module.open(path, convert_open_mode_to_flags(mode, o_binary=hasattr(os_module, "O_BINARY"), os_module=os_module))
    fh = os_module.fdopen(fd, mode, closefd=True)
    #XXX what about using `fh = os_module.fdopen(path, mode, closefd=True, opener=os_module.open)`
    return fh
  except Exception:
    if fd is not None: os_module.close(fd)
    raise
open2._required_globals = ["os", "convert_open_mode_to_flags"]
