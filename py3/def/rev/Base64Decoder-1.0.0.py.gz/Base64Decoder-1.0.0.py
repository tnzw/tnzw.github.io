# Base64Decoder.py Version 1.0.0
# Copyright (c) 2021 Tristan Cavelier <t.cavelier@free.fr>
# This program is free software. It comes without any warranty, to
# the extent permitted by applicable law. You can redistribute it
# and/or modify it under the terms of the Do What The Fuck You Want
# To Public License, Version 2, as published by Sam Hocevar. See
# http://www.wtfpl.net/ for more details.

class Base64Decoder(object):
  """\
Base64Decoder(**opt)

opt:
  errors => "strict"          : (default) raise on any error
         => "pad"             : add base64 padding before EOF if necessary (eg b"RS" → b"RS==")
         => "ignore"          : ignore unexpected characters
                                ex: b"R=K==A=B=L~OZ" → b"RK==ABLO"
  scheme : The scheme to use bytes(64)
         => b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/' (default)
  ignored => b" \n\r\t": ignores each one of these bytes from input
  padding => b"=": each one of these bytes may be concidered as padding
  cast => bytes: (default) cast the returned transcoded values to bytes.
       => None : do not cast, returns transcoded byte iterator instead.
  cache        : internal use only.
  state        : internal use only.

Interfaces:
- copyable (ie. `copy()`)
- transcoder (ie. `transcode(iterable=None, *, stream=False)`)
"""
  STANDARD_SCHEME = b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
  URL_SCHEME = b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'
  def copy(self): return self.__class__(**{k: v for k, v in self.__dict__.items()})
  def __init__(self, *, errors="strict", scheme=b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/', padding=b"=", ignored=b" \n\r\t", cast=bytes, cache=0, state=0):
    self.errors = errors
    self.scheme = scheme
    self.padding = padding
    self.ignored = ignored
    self.cast = cast
    self.cache = cache
    self.state = state
  def transcode(self, iterable=None, *, stream=False):
    """\
transcode(iterable, **opt)

iterable: a byte iterable value (defaults to None)
opt:
  stream => False: tells the transcoder that it is the last transcode operation
         => True
"""
    if iterable is None: iterable = ()
    # states are:
    # 0 => [?...]
    # 1 => [A?..]
    # 2 => [AB?.]
    # 3 => [ABC?]
    # 4 => [AB=?]

    def check_errors(errors):
      if errors in ("strict", "pad", "ignore"): return errors
      raise LookupError(f"unknown error handler name {errors!r}")

    def it():
      errors, scheme, ignored, padding = self.errors, self.scheme[:64], self.ignored, self.padding
      cache, state = self.cache, self.state

      for b in iterable:
        if b not in ignored:

          if b in padding:
            if state in (3, 4): state = 0  # [ABC=] [AB==]
            elif state in (2,): state = 4  # [AB=.]
            else:  # [=...] [A=..]
              if errors != "ignore":
                check_errors(errors)
                raise ValueError("unexpected padding")
          else:
            code = scheme.find(b)
            if code != -1:
              if state == 0: pass  # [A...]
              elif state == 1: yield (cache << 2) | (code >> 4)  # [AB..]
              elif state == 2: yield ((cache & 0xF) << 4) | (code >> 2)  # [ABC.]
              elif state == 3: yield ((cache & 0x3) << 6) | code  # [ABCD]
              cache = code
              state = (state + 1) % 4
            elif errors != "ignore":
              check_errors(errors)
              raise ValueError("invalid code")

      if stream:
        self.cache, self.state = cache, state
        return

      if state == 0: pass
      elif errors == "ignore": state = 0
      elif errors == "pad":
        if state == 1: raise ValueError("unexpected end of data")
        state = 0
      else:
        check_errors(errors)
        raise ValueError("unexpected end of data")

      self.cache, self.state = cache, state
    return it() if self.cast is None else self.cast(it())
  decode = transcode
