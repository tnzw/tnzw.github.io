this.ArrayViewEntriesIterator = (function script() {

  /*! ArrayViewEntriesIterator.js Version 1.0.0

      Copyright (c) 2017 Tristan Cavelier <t.cavelier@free.fr>
      This program is free software. It comes without any warranty, to
      the extent permitted by applicable law. You can redistribute it
      and/or modify it under the terms of the Do What The Fuck You Want
      To Public License, Version 2, as published by Sam Hocevar. See
      http://www.wtfpl.net/ for more details. */

  function ArrayViewEntriesIterator(array, offset, length) {
    this.array = array;
    if (offset !== undefined) this.offset = offset | 0;
    if (length !== undefined) this.length = length | 0;
  }
  ArrayViewEntriesIterator.prototype.index = 0;
  ArrayViewEntriesIterator.prototype.next = function () {
    var pos = this.offset + this.index;
    if (pos < this.offset + this.length) {
      return {
        done: false,
        value: [this.index++, this.array[pos]]
      };
    }
    return {
      done: true,
      value: undefined
    };
  };

  ArrayViewEntriesIterator.toScript = function () { return "(" + script.toString() + "())"; };
  return ArrayViewEntriesIterator;

}());
