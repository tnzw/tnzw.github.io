this.toScript = (function script(global) {
  "use strict";

  /*! toScript.js Version 1.1.0

      Copyright (c) 2017 Tristan Cavelier <t.cavelier@free.fr>
      This program is free software. It comes without any warranty, to
      the extent permitted by applicable law. You can redistribute it
      and/or modify it under the terms of the Do What The Fuck You Want
      To Public License, Version 2, as published by Sam Hocevar. See
      http://www.wtfpl.net/ for more details. */

  function toScript(names) {
    var handled = {};
    function asprop(name) {
      if ((/^[_a-z\$][_a-z0-9\$]*$/i).test(name))
        return "." + name;
      return "[" + JSON.stringify(name) + "]";
    }
    function rec(name) {
      var s = "";
      name += "";
      if (handled[name]) return "";
      handled[name] = true;
      if (global[name] === undefined) {
        return "";
      } else if (typeof global[name] === "function") {
        if (Array.isArray(global[name]._requiredGlobals))
          s = global[name]._requiredGlobals.map(rec).join(";\n") + ";\n";
        if (typeof global[name].toScript === "function")
          return s + "this" + asprop(name) + " = " + global[name].toScript();
        return s + "this" + asprop(name) + " = " + global[name].toString();
      } else {
        throw new Error("unhandled type `" + (typeof global[name]) + "`");
      }
      throw new Error("not implemented");
    }
    return names.map(rec).join(";\n") + ";";
  }
  toScript.toScript = function () { return "(" + script.toString() + "())"; };
  return toScript;

}(this));
