this.ArrayView = (function script() {

  /*! ArrayView.js Version 1.0.0

      Copyright (c) 2017 Tristan Cavelier <t.cavelier@free.fr>
      This program is free software. It comes without any warranty, to
      the extent permitted by applicable law. You can redistribute it
      and/or modify it under the terms of the Do What The Fuck You Want
      To Public License, Version 2, as published by Sam Hocevar. See
      http://www.wtfpl.net/ for more details. */

  function ArrayView(array, offset, length) {
    // ArrayView(array [, offset [, length]])
    this.array = array;
    if (offset !== undefined) this.offset = offset | 0;
    if (length !== undefined) this.length = length | 0;
    else this.length = array.length | 0;
  }
  ArrayView.prototype.offset = 0;
  ArrayView.prototype.length = 0;
  ArrayView.prototype.entries = function () {
    return new ArrayViewEntriesIterator(this.array, this.offset, this.length);
  };
  ArrayView.prototype.values = function () {
    return new ArrayViewValuesIterator(this.array, this.offset, this.length);
  };

  ArrayView.prototype.subarray = function (begin, end) {
    if (begin === undefined) begin = this.offset;
    else if (begin < 0) begin = this.offset + this.length + begin;
    if (end === undefined) end = this.offset + this.length;
    else if (end < 0) end = this.offset + this.length + end;
    return new ArrayView(this.array, this.offset, this.length);
  };
  ArrayView.prototype.get = function (index) {
    index |= 0;
    if (index < 0) return;
    index = this.offset + index;
    if (index >= this.offset + this.length) return;
    return this.array[index];
  };
  ArrayView.prototype.set = function (array, offset) {
    if (offset === undefined) offset = 0;
    else offset = offset | 0;
    offset += this.offset;
    var g = null, max = this.offset + this.length, i = 0, n = null;
    if (typeof array.values === "function") {
      g = array.values();
      while (offset < max && !(n = g.next()).done)
        this.array[offset++] = n.value;
    } else {
      while (offset < max && i < array.length)
        this.array[offset++] = array[i++];
    }
  };

  ArrayView.prototype.readAsArray = function () {
    var a = new Array(this.length), j = 0,
        i = this.offset, max = i + this.length;
    while (i < max) a[j++] = this.array[i++];
    return a;
  };
  ArrayView.prototype.pushInto = function (pushable) {
    var i = this.offset, max = i + this.length;
    while (i < max) pushable.push(this.array[i++]);
    return pushable;
  };

  ArrayView.toScript = function () { return "(" + script.toString() + "())"; };
  ArrayView._requiredGlobals = [
    "ArrayViewEntriesIterator",
    "ArrayViewValuesIterator"
  ];
  return ArrayView;

}());
