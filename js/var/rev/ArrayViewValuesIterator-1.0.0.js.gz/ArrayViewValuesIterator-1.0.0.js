this.ArrayViewValuesIterator = (function script() {

  /*! ArrayViewValuesIterator.js Version 1.0.0

      Copyright (c) 2017 Tristan Cavelier <t.cavelier@free.fr>
      This program is free software. It comes without any warranty, to
      the extent permitted by applicable law. You can redistribute it
      and/or modify it under the terms of the Do What The Fuck You Want
      To Public License, Version 2, as published by Sam Hocevar. See
      http://www.wtfpl.net/ for more details. */

  function ArrayViewValuesIterator(array, offset, length) {
    this.array = array;
    if (offset !== undefined) this.offset = offset | 0;
    if (length !== undefined) this.length = length | 0;
  }
  ArrayViewValuesIterator.prototype.index = 0;
  ArrayViewValuesIterator.prototype.next = function () {
    var pos = this.offset + this.index;
    if (pos < this.offset + this.length) {
      return {
        done: false,
        value: this.array[pos]
      };
    }
    return {
      done: true,
      value: undefined
    };
  };

  ArrayViewValuesIterator.toScript = function () { return "(" + script.toString() + "())"; };
  return ArrayViewValuesIterator;

}());
